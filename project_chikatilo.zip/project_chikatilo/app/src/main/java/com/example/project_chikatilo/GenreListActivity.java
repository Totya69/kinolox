// GenreListActivity.java
package com.example.project_chikatilo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;
import java.util.List;

public class GenreListActivity extends AppCompatActivity {

    private static final List<String> GENRES = Arrays.asList(
            "Ужасы", "Слэшеры", "Детектив", "Боевик", "Драма"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_genre_list);

        ListView listView = findViewById(R.id.listViewGenres);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_genre, GENRES);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedGenre = GENRES.get(position);
            Intent intent = new Intent(GenreListActivity.this, MovieListActivity.class);
            intent.putExtra("genre", selectedGenre);
            startActivity(intent);
        });
    }
}