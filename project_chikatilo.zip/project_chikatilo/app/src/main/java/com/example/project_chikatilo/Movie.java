// Movie.java
package com.example.project_chikatilo;

public class Movie {
    private String title;
    private String description;
    private String genre; // "ужасы", "слэшеры", и т.д.

    public Movie(String title, String description, String genre) {
        this.title = title;
        this.description = description;
        this.genre = genre;
    }

    // Геттеры
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getGenre() { return genre; }
}