// MovieListActivity.java
package com.example.project_chikatilo;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MovieListActivity extends AppCompatActivity {

    private String selectedGenre;
    private List<Movie> allMovies = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_list);

        selectedGenre = getIntent().getStringExtra("genre");
        initMovies();

        List<Movie> filtered = new ArrayList<>();
        for (Movie m : allMovies) {
            if (m.getGenre().equals(selectedGenre)) {
                filtered.add(m);
            }
        }

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        MovieAdapter adapter = new MovieAdapter(filtered, movie -> {
            Intent intent = new Intent(MovieListActivity.this, PlayerActivity.class);
            intent.putExtra("title", movie.getTitle());
            intent.putExtra("description", movie.getDescription());
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);
    }

    private void initMovies() {
        // Ужасы
        allMovies.add(new Movie("Сияние", "Психологический ужас в заброшенном отеле.", "Ужасы"));
        allMovies.add(new Movie("Изгоняющий дьявола", "Экзорцизм одержимой девочки.", "Ужасы"));
        allMovies.add(new Movie("Хэллоуин", "Майкл Майерс преследует подростков.", "Ужасы"));
        allMovies.add(new Movie("Полтергейст", "Дом, захваченный духами.", "Ужасы"));
        allMovies.add(new Movie("Оно", "Клоун Пеннивайз пугает детей.", "Ужасы"));

        // Слэшеры
        allMovies.add(new Movie("Пятница, 13-е", "Джейсон убивает лагерников.", "Слэшеры"));
        allMovies.add(new Movie("Крик", "Убийца в маске звонит жертвам.", "Слэшеры"));
        allMovies.add(new Movie("Техасская резня бензопилой", "Семья каннибалов.", "Слэшеры"));
        allMovies.add(new Movie("Ночь живых мертвецов", "Зомби-апокалипсис.", "Слэшеры"));
        allMovies.add(new Movie("Чужой", "Ксеноморф на космическом корабле.", "Слэшеры"));

        // Детектив
        allMovies.add(new Movie("Семь", "Серийный убийца по семи смертным грехам.", "Детектив"));
        allMovies.add(new Movie("Молчание ягнят", "ФБР против каннибала Лектера.", "Детектив"));
        allMovies.add(new Movie("Престиж", "Соперничество фокусников.", "Детектив"));
        allMovies.add(new Movie("Шестое чувство", "Психологическая тайна.", "Детектив"));
        allMovies.add(new Movie("Город грехов", "Темные истории в Бэйсин-Сити.", "Детектив"));

        // Боевик
        allMovies.add(new Movie("Терминатор 2", "Т-800 защищает Джона Коннора.", "Боевик"));
        allMovies.add(new Movie("Крепкий орешек", "Полицейский против террористов.", "Боевик"));
        allMovies.add(new Movie("Матрица", "Нео против машин.", "Боевик"));
        allMovies.add(new Movie("Миссия невыполнима", "Итан Хант спасает мир.", "Боевик"));
        allMovies.add(new Movie("Джон Уик", "Легенда возвращается.", "Боевик"));

        // Драма
        allMovies.add(new Movie("Побег из Шоушенка", "Надежда в тюрьме.", "Драма"));
        allMovies.add(new Movie("Зеленая миля", "Смертники и чудеса.", "Драма"));
        allMovies.add(new Movie("Форрест Гамп", "История простого человека.", "Драма"));
        allMovies.add(new Movie("1+1", "Дружба инвалида и иммигранта.", "Драма"));
        allMovies.add(new Movie("Список Шиндлера", "Спасение евреев в Холокост.", "Драма"));
    }
}