// PlayerActivity.java
package com.example.project_chikatilo;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PlayerActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private boolean isPlaying = false;
    private AudioManager audioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        String title = getIntent().getStringExtra("title");
        String description = getIntent().getStringExtra("description");

        TextView tvTitle = findViewById(R.id.tvPlayerTitle);
        tvTitle.setText(title);

        // Имитация плеера (без реального видео)
        Button btnPlayPause = findViewById(R.id.btnPlayPause);
        btnPlayPause.setOnClickListener(v -> {
            isPlaying = !isPlaying;
            btnPlayPause.setText(isPlaying ? "⏸ Пауза" : "▶ Воспроизвести");
            Toast.makeText(this, isPlaying ? "Воспроизведение..." : "Пауза", Toast.LENGTH_SHORT).show();
        });

        // Громкость
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        SeekBar volumeControl = findViewById(R.id.seekBarVolume);
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        volumeControl.setMax(maxVolume);
        volumeControl.setProgress(currentVolume);

        volumeControl.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Комментарий
        EditText etComment = findViewById(R.id.etComment);
        Button btnSend = findViewById(R.id.btnSendComment);
        btnSend.setOnClickListener(v -> {
            String comment = etComment.getText().toString().trim();
            if (!comment.isEmpty()) {
                Toast.makeText(this, "Комментарий отправлен!", Toast.LENGTH_SHORT).show();
                etComment.setText("");
            } else {
                Toast.makeText(this, "Введите комментарий", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }
}